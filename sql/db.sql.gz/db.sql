-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: db:3306
-- Generation Time: Mar 03, 2024 at 12:37 PM
-- Server version: 10.4.32-MariaDB-1:10.4.32+maria~ubu2004-log
-- PHP Version: 8.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db`
--

-- --------------------------------------------------------

--
-- Table structure for table `logbooks`
--

DROP TABLE IF EXISTS `logbooks`;
CREATE TABLE `logbooks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `planet_id` bigint(20) UNSIGNED NOT NULL,
  `mood` varchar(255) DEFAULT NULL,
  `weather` varchar(255) DEFAULT NULL,
  `gps_location` varchar(255) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `logbooks`
--

INSERT INTO `logbooks` (`id`, `planet_id`, `mood`, `weather`, `gps_location`, `note`, `created_at`, `updated_at`) VALUES
(1, 57, 'eyJpdiI6InZLUlZWb2dqSm9CemNYUnJoWDRERFE9PSIsInZhbHVlIjoiOEVUK1dOeEZVRHBvT2VyNXF6aHJFdz09IiwibWFjIjoiYjRkNjQ3ZjVhNzYyMjUwNmI1NmY0MDY1YzJkMWU3ZGNlNmJjNWM4YmFlZGJkOGI1ZGE2MDNkYTVkZDQ5NjI2MyIsInRhZyI6IiJ9', 'eyJpdiI6IjRGVjFNdVpwWkphOUhoeHdmd1prZ0E9PSIsInZhbHVlIjoiY0N0aldVejMvaXVCU01nYmNNaitWQT09IiwibWFjIjoiY2QyZjQ0ZDlmOTFkZjljY2E4NWExZjcxNjE5M2VmYmVhNGU3NmJkNjkzOGRjZWMyYzc3ODU3NjBiNjVmYTY5NyIsInRhZyI6IiJ9', 'eyJpdiI6IkIrRTRZaXNsa1JQSS9hQ0FmdHVTUnc9PSIsInZhbHVlIjoiZFNpRTEraXJ1RjR2NElFM3BlZGFndz09IiwibWFjIjoiZmE5M2NhYjA5M2JiNTUxZmUzZjk1MGE1Zjc2MmNhZTQ5YzcyZThmZjhiZDE1NjczY2FhNTkxMGNmYWVkNWYxZCIsInRhZyI6IiJ9', 'eyJpdiI6Ik5CdW1aMktvNXB2R3UxbkhKU0JWTkE9PSIsInZhbHVlIjoiOUp4ZGU1ZjE2cjhVSllnY0Jnd2tya0M4R1FmMmorZWVsOWxuN0lKNm1NND0iLCJtYWMiOiJlYzA5NTkxNTFjNTcyODUzMjkyYzI3MDg3YjQ0Yzg4NDUxY2EwMDYyMTQ0NzkwNmNhZjY0M2VhMjNkZGZhNTJlIiwidGFnIjoiIn0=', '2024-03-03 12:36:30', '2024-03-03 12:36:30'),
(2, 58, 'eyJpdiI6InY3Kys0eVZ5cS9KcmVJNTl6Y1pFSXc9PSIsInZhbHVlIjoiWFhKSXpTbHhyUlNWUHVqbFROOFhZdz09IiwibWFjIjoiN2U3ZDVlNzA4ODAyMWMyMDhkY2RiMjQwMDc1ZmMxMWY1YjgyZTlkNzdlM2JlODNkNDIxMGExMGQ4YmRjYjliOCIsInRhZyI6IiJ9', 'eyJpdiI6IktzOTE4eU4vVzI1OFpyS0lwZWN4cnc9PSIsInZhbHVlIjoiM3MrbzdiYUtEVnVCQUpTd2VlUDd5QT09IiwibWFjIjoiMmNkYjI3NjIyNzFmNWU4ZDg3ZmMwYjNlY2FmMDkzZmVkMDk0MTgwZTNhZGQwZTBjYmEzYjQ3NDBiZTI2Y2Y5ZSIsInRhZyI6IiJ9', 'eyJpdiI6ImRjVmt1Mjh1Y2Z4d09qaXhPSjNLTVE9PSIsInZhbHVlIjoibDNicHBCS1BXRG5PUXpzRjgzSmV3Zz09IiwibWFjIjoiY2I0NDg1ZDQ4NDgyNmVmNmU1ODBhZDU0YjQzNmM4ZWZmMmJmOTJkODQxY2ZhNDFlNjIxYzMwMzY2NjQ5MzUzMyIsInRhZyI6IiJ9', 'eyJpdiI6IitpdTE5TXZKdm9qd2JyNGd0VEVndWc9PSIsInZhbHVlIjoiQXFPTlBLRVZRQ3ZYMjdmMHlRdDJ0RkJRbytwRjdPc25RK1NzV2JUU1lGQT0iLCJtYWMiOiJjMzE2ZTk3MTcwMTYzYjhhYzljMGU3NmExODZlYTVjOGI3MjI0Y2ZlZWI0NWRmYTA5NTY1ZjE0OWI2MzZhMWE3IiwidGFnIjoiIn0=', '2024-03-03 12:36:30', '2024-03-03 12:36:30'),
(3, 59, 'eyJpdiI6Ikt6a2xnY055VUFuenZvNEpXSTZ1bFE9PSIsInZhbHVlIjoidGtjUVpKclpDTWw2Q0prdXA3NGw1dz09IiwibWFjIjoiYTJmNGNmMzEyOTM2MTQyYTU2ODQ1N2M4MzRhOWFmNDEwMWExNzIxNzkzYTVmNDZhMDY2N2UyZjgxOTFiY2UxMCIsInRhZyI6IiJ9', 'eyJpdiI6IlRVYjN4WHVud3dsYmhGNXhLeE0rSEE9PSIsInZhbHVlIjoiSmZwWXhmdmJHcWhzdExxeS93TWJBdz09IiwibWFjIjoiNmQ4ZGEyYTJkZWI5YjUwMTM0NmZmYjY3MTdjY2UzZjI1NjMwZWRkOTI1YjY0OWZjMzc5MjQ2NDU3MzBkNTMzMiIsInRhZyI6IiJ9', 'eyJpdiI6IlhYcGRadTUxR2ZqSmRkZ1hkZmFBZUE9PSIsInZhbHVlIjoiMGxKM0NPZml5azNQeDA5UGVtQnZXQT09IiwibWFjIjoiOGU4ZmVjNDYzODk1MTY2MGUxZDg0MjI1YTcxOTQ2MTQ2OTU2MmMwMzViZmQ3ZTE2YzdiZGYyODkyZDRmNTU2YSIsInRhZyI6IiJ9', 'eyJpdiI6Im02WVl4ZmlibFVMQldMQTM4UGgxakE9PSIsInZhbHVlIjoiRTdwaVVqR2h4TTdKbkxXSi9sVW5EOHBNRGZsWDFtUFc2OHU1VnZETmFKWT0iLCJtYWMiOiI5N2ViNjgzYzA1NWE1MjU3YTIzNmIyMjM5MWE4YjZjNTZkMmEzMTYxYjE4NTZkODlmODViMzgwMDMxODI4MDAwIiwidGFnIjoiIn0=', '2024-03-03 12:36:30', '2024-03-03 12:36:30');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(2, '2024_02_28_173959_create_planets_table', 1),
(3, '2024_02_28_174000_create_species_table', 1),
(4, '2024_02_28_174001_create_residents_table', 1),
(5, '2024_03_02_154320_create_logbooks_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `planets`
--

DROP TABLE IF EXISTS `planets`;
CREATE TABLE `planets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `rotation_period` varchar(255) DEFAULT NULL,
  `orbital_period` varchar(255) DEFAULT NULL,
  `diameter` varchar(255) DEFAULT NULL,
  `climate` varchar(255) DEFAULT NULL,
  `gravity` varchar(255) DEFAULT NULL,
  `terrain` varchar(255) DEFAULT NULL,
  `surface_water` varchar(255) DEFAULT NULL,
  `population` varchar(255) DEFAULT NULL,
  `url` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `planets`
--

INSERT INTO `planets` (`id`, `name`, `rotation_period`, `orbital_period`, `diameter`, `climate`, `gravity`, `terrain`, `surface_water`, `population`, `url`, `created_at`, `updated_at`) VALUES
(1, 'Tatooine', '23', '304', '10465', 'arid', '1 standard', 'desert', '1', '200000', 'https://swapi.py4e.com/api/planets/1/', '2024-03-03 12:35:45', '2024-03-03 12:35:45'),
(2, 'Alderaan', '24', '364', '12500', 'temperate', '1 standard', 'grasslands, mountains', '40', '2000000000', 'https://swapi.py4e.com/api/planets/2/', '2024-03-03 12:35:47', '2024-03-03 12:35:47'),
(3, 'Yavin IV', '24', '4818', '10200', 'temperate, tropical', '1 standard', 'jungle, rainforests', '8', '1000', 'https://swapi.py4e.com/api/planets/3/', '2024-03-03 12:35:48', '2024-03-03 12:35:48'),
(4, 'Hoth', '23', '549', '7200', 'frozen', '1.1 standard', 'tundra, ice caves, mountain ranges', '100', 'unknown', 'https://swapi.py4e.com/api/planets/4/', '2024-03-03 12:35:48', '2024-03-03 12:35:48'),
(5, 'Dagobah', '23', '341', '8900', 'murky', 'N/A', 'swamp, jungles', '8', 'unknown', 'https://swapi.py4e.com/api/planets/5/', '2024-03-03 12:35:48', '2024-03-03 12:35:48'),
(6, 'Bespin', '12', '5110', '118000', 'temperate', '1.5 (surface), 1 standard (Cloud City)', 'gas giant', '0', '6000000', 'https://swapi.py4e.com/api/planets/6/', '2024-03-03 12:35:48', '2024-03-03 12:35:48'),
(7, 'Endor', '18', '402', '4900', 'temperate', '0.85 standard', 'forests, mountains, lakes', '8', '30000000', 'https://swapi.py4e.com/api/planets/7/', '2024-03-03 12:35:48', '2024-03-03 12:35:48'),
(8, 'Naboo', '26', '312', '12120', 'temperate', '1 standard', 'grassy hills, swamps, forests, mountains', '12', '4500000000', 'https://swapi.py4e.com/api/planets/8/', '2024-03-03 12:35:49', '2024-03-03 12:35:49'),
(9, 'Coruscant', '24', '368', '12240', 'temperate', '1 standard', 'cityscape, mountains', 'unknown', '1000000000000', 'https://swapi.py4e.com/api/planets/9/', '2024-03-03 12:35:51', '2024-03-03 12:35:51'),
(10, 'Kamino', '27', '463', '19720', 'temperate', '1 standard', 'ocean', '100', '1000000000', 'https://swapi.py4e.com/api/planets/10/', '2024-03-03 12:35:51', '2024-03-03 12:35:51'),
(11, 'Geonosis', '30', '256', '11370', 'temperate, arid', '0.9 standard', 'rock, desert, mountain, barren', '5', '100000000000', 'https://swapi.py4e.com/api/planets/11/', '2024-03-03 12:35:53', '2024-03-03 12:35:53'),
(12, 'Utapau', '27', '351', '12900', 'temperate, arid, windy', '1 standard', 'scrublands, savanna, canyons, sinkholes', '0.9', '95000000', 'https://swapi.py4e.com/api/planets/12/', '2024-03-03 12:35:54', '2024-03-03 12:35:54'),
(13, 'Mustafar', '36', '412', '4200', 'hot', '1 standard', 'volcanoes, lava rivers, mountains, caves', '0', '20000', 'https://swapi.py4e.com/api/planets/13/', '2024-03-03 12:35:54', '2024-03-03 12:35:54'),
(14, 'Kashyyyk', '26', '381', '12765', 'tropical', '1 standard', 'jungle, forests, lakes, rivers', '60', '45000000', 'https://swapi.py4e.com/api/planets/14/', '2024-03-03 12:35:54', '2024-03-03 12:35:54'),
(15, 'Polis Massa', '24', '590', '0', 'artificial temperate ', '0.56 standard', 'airless asteroid', '0', '1000000', 'https://swapi.py4e.com/api/planets/15/', '2024-03-03 12:35:55', '2024-03-03 12:35:55'),
(16, 'Mygeeto', '12', '167', '10088', 'frigid', '1 standard', 'glaciers, mountains, ice canyons', 'unknown', '19000000', 'https://swapi.py4e.com/api/planets/16/', '2024-03-03 12:35:55', '2024-03-03 12:35:55'),
(17, 'Felucia', '34', '231', '9100', 'hot, humid', '0.75 standard', 'fungus forests', 'unknown', '8500000', 'https://swapi.py4e.com/api/planets/17/', '2024-03-03 12:35:55', '2024-03-03 12:35:55'),
(18, 'Cato Neimoidia', '25', '278', '0', 'temperate, moist', '1 standard', 'mountains, fields, forests, rock arches', 'unknown', '10000000', 'https://swapi.py4e.com/api/planets/18/', '2024-03-03 12:35:55', '2024-03-03 12:35:55'),
(19, 'Saleucami', '26', '392', '14920', 'hot', 'unknown', 'caves, desert, mountains, volcanoes', 'unknown', '1400000000', 'https://swapi.py4e.com/api/planets/19/', '2024-03-03 12:35:56', '2024-03-03 12:35:56'),
(20, 'Stewjon', 'unknown', 'unknown', '0', 'temperate', '1 standard', 'grass', 'unknown', 'unknown', 'https://swapi.py4e.com/api/planets/20/', '2024-03-03 12:35:56', '2024-03-03 12:35:56'),
(21, 'Eriadu', '24', '360', '13490', 'polluted', '1 standard', 'cityscape', 'unknown', '22000000000', 'https://swapi.py4e.com/api/planets/21/', '2024-03-03 12:35:57', '2024-03-03 12:35:57'),
(22, 'Corellia', '25', '329', '11000', 'temperate', '1 standard', 'plains, urban, hills, forests', '70', '3000000000', 'https://swapi.py4e.com/api/planets/22/', '2024-03-03 12:35:57', '2024-03-03 12:35:57'),
(23, 'Rodia', '29', '305', '7549', 'hot', '1 standard', 'jungles, oceans, urban, swamps', '60', '1300000000', 'https://swapi.py4e.com/api/planets/23/', '2024-03-03 12:35:58', '2024-03-03 12:35:58'),
(24, 'Nal Hutta', '87', '413', '12150', 'temperate', '1 standard', 'urban, oceans, swamps, bogs', 'unknown', '7000000000', 'https://swapi.py4e.com/api/planets/24/', '2024-03-03 12:35:58', '2024-03-03 12:35:58'),
(25, 'Dantooine', '25', '378', '9830', 'temperate', '1 standard', 'oceans, savannas, mountains, grasslands', 'unknown', '1000', 'https://swapi.py4e.com/api/planets/25/', '2024-03-03 12:35:59', '2024-03-03 12:35:59'),
(26, 'Bestine IV', '26', '680', '6400', 'temperate', 'unknown', 'rocky islands, oceans', '98', '62000000', 'https://swapi.py4e.com/api/planets/26/', '2024-03-03 12:35:59', '2024-03-03 12:35:59'),
(27, 'Ord Mantell', '26', '334', '14050', 'temperate', '1 standard', 'plains, seas, mesas', '10', '4000000000', 'https://swapi.py4e.com/api/planets/27/', '2024-03-03 12:35:59', '2024-03-03 12:35:59'),
(28, 'unknown', '0', '0', '0', 'unknown', 'unknown', 'unknown', 'unknown', 'unknown', 'https://swapi.py4e.com/api/planets/28/', '2024-03-03 12:35:59', '2024-03-03 12:35:59'),
(29, 'Trandosha', '25', '371', '0', 'arid', '0.62 standard', 'mountains, seas, grasslands, deserts', 'unknown', '42000000', 'https://swapi.py4e.com/api/planets/29/', '2024-03-03 12:36:03', '2024-03-03 12:36:03'),
(30, 'Socorro', '20', '326', '0', 'arid', '1 standard', 'deserts, mountains', 'unknown', '300000000', 'https://swapi.py4e.com/api/planets/30/', '2024-03-03 12:36:03', '2024-03-03 12:36:03'),
(31, 'Mon Cala', '21', '398', '11030', 'temperate', '1', 'oceans, reefs, islands', '100', '27000000000', 'https://swapi.py4e.com/api/planets/31/', '2024-03-03 12:36:04', '2024-03-03 12:36:04'),
(32, 'Chandrila', '20', '368', '13500', 'temperate', '1', 'plains, forests', '40', '1200000000', 'https://swapi.py4e.com/api/planets/32/', '2024-03-03 12:36:05', '2024-03-03 12:36:05'),
(33, 'Sullust', '20', '263', '12780', 'superheated', '1', 'mountains, volcanoes, rocky deserts', '5', '18500000000', 'https://swapi.py4e.com/api/planets/33/', '2024-03-03 12:36:05', '2024-03-03 12:36:05'),
(34, 'Toydaria', '21', '184', '7900', 'temperate', '1', 'swamps, lakes', 'unknown', '11000000', 'https://swapi.py4e.com/api/planets/34/', '2024-03-03 12:36:06', '2024-03-03 12:36:06'),
(35, 'Malastare', '26', '201', '18880', 'arid, temperate, tropical', '1.56', 'swamps, deserts, jungles, mountains', 'unknown', '2000000000', 'https://swapi.py4e.com/api/planets/35/', '2024-03-03 12:36:07', '2024-03-03 12:36:07'),
(36, 'Dathomir', '24', '491', '10480', 'temperate', '0.9', 'forests, deserts, savannas', 'unknown', '5200', 'https://swapi.py4e.com/api/planets/36/', '2024-03-03 12:36:07', '2024-03-03 12:36:07'),
(37, 'Ryloth', '30', '305', '10600', 'temperate, arid, subartic', '1', 'mountains, valleys, deserts, tundra', '5', '1500000000', 'https://swapi.py4e.com/api/planets/37/', '2024-03-03 12:36:08', '2024-03-03 12:36:08'),
(38, 'Aleen Minor', 'unknown', 'unknown', 'unknown', 'unknown', 'unknown', 'unknown', 'unknown', 'unknown', 'https://swapi.py4e.com/api/planets/38/', '2024-03-03 12:36:09', '2024-03-03 12:36:09'),
(39, 'Vulpter', '22', '391', '14900', 'temperate, artic', '1', 'urban, barren', 'unknown', '421000000', 'https://swapi.py4e.com/api/planets/39/', '2024-03-03 12:36:09', '2024-03-03 12:36:09'),
(40, 'Troiken', 'unknown', 'unknown', 'unknown', 'unknown', 'unknown', 'desert, tundra, rainforests, mountains', 'unknown', 'unknown', 'https://swapi.py4e.com/api/planets/40/', '2024-03-03 12:36:10', '2024-03-03 12:36:10'),
(41, 'Tund', '48', '1770', '12190', 'unknown', 'unknown', 'barren, ash', 'unknown', '0', 'https://swapi.py4e.com/api/planets/41/', '2024-03-03 12:36:11', '2024-03-03 12:36:11'),
(42, 'Haruun Kal', '25', '383', '10120', 'temperate', '0.98', 'toxic cloudsea, plateaus, volcanoes', 'unknown', '705300', 'https://swapi.py4e.com/api/planets/42/', '2024-03-03 12:36:11', '2024-03-03 12:36:11'),
(43, 'Cerea', '27', '386', 'unknown', 'temperate', '1', 'verdant', '20', '450000000', 'https://swapi.py4e.com/api/planets/43/', '2024-03-03 12:36:12', '2024-03-03 12:36:12'),
(44, 'Glee Anselm', '33', '206', '15600', 'tropical, temperate', '1', 'lakes, islands, swamps, seas', '80', '500000000', 'https://swapi.py4e.com/api/planets/44/', '2024-03-03 12:36:12', '2024-03-03 12:36:12'),
(45, 'Iridonia', '29', '413', 'unknown', 'unknown', 'unknown', 'rocky canyons, acid pools', 'unknown', 'unknown', 'https://swapi.py4e.com/api/planets/45/', '2024-03-03 12:36:13', '2024-03-03 12:36:13'),
(46, 'Tholoth', 'unknown', 'unknown', 'unknown', 'unknown', 'unknown', 'unknown', 'unknown', 'unknown', 'https://swapi.py4e.com/api/planets/46/', '2024-03-03 12:36:13', '2024-03-03 12:36:13'),
(47, 'Iktotch', '22', '481', 'unknown', 'arid, rocky, windy', '1', 'rocky', 'unknown', 'unknown', 'https://swapi.py4e.com/api/planets/47/', '2024-03-03 12:36:13', '2024-03-03 12:36:13'),
(48, 'Quermia', 'unknown', 'unknown', 'unknown', 'unknown', 'unknown', 'unknown', 'unknown', 'unknown', 'https://swapi.py4e.com/api/planets/48/', '2024-03-03 12:36:14', '2024-03-03 12:36:14'),
(49, 'Dorin', '22', '409', '13400', 'temperate', '1', 'unknown', 'unknown', 'unknown', 'https://swapi.py4e.com/api/planets/49/', '2024-03-03 12:36:14', '2024-03-03 12:36:14'),
(50, 'Champala', '27', '318', 'unknown', 'temperate', '1', 'oceans, rainforests, plateaus', 'unknown', '3500000000', 'https://swapi.py4e.com/api/planets/50/', '2024-03-03 12:36:15', '2024-03-03 12:36:15'),
(51, 'Mirial', 'unknown', 'unknown', 'unknown', 'unknown', 'unknown', 'deserts', 'unknown', 'unknown', 'https://swapi.py4e.com/api/planets/51/', '2024-03-03 12:36:16', '2024-03-03 12:36:16'),
(52, 'Serenno', 'unknown', 'unknown', 'unknown', 'unknown', 'unknown', 'rainforests, rivers, mountains', 'unknown', 'unknown', 'https://swapi.py4e.com/api/planets/52/', '2024-03-03 12:36:17', '2024-03-03 12:36:17'),
(53, 'Concord Dawn', 'unknown', 'unknown', 'unknown', 'unknown', 'unknown', 'jungles, forests, deserts', 'unknown', 'unknown', 'https://swapi.py4e.com/api/planets/53/', '2024-03-03 12:36:17', '2024-03-03 12:36:17'),
(54, 'Zolan', 'unknown', 'unknown', 'unknown', 'unknown', 'unknown', 'unknown', 'unknown', 'unknown', 'https://swapi.py4e.com/api/planets/54/', '2024-03-03 12:36:17', '2024-03-03 12:36:17'),
(55, 'Ojom', 'unknown', 'unknown', 'unknown', 'frigid', 'unknown', 'oceans, glaciers', '100', '500000000', 'https://swapi.py4e.com/api/planets/55/', '2024-03-03 12:36:18', '2024-03-03 12:36:18'),
(56, 'Skako', '27', '384', 'unknown', 'temperate', '1', 'urban, vines', 'unknown', '500000000000', 'https://swapi.py4e.com/api/planets/56/', '2024-03-03 12:36:19', '2024-03-03 12:36:19'),
(57, 'Muunilinst', '28', '412', '13800', 'temperate', '1', 'plains, forests, hills, mountains', '25', '5000000000', 'https://swapi.py4e.com/api/planets/57/', '2024-03-03 12:36:19', '2024-03-03 12:36:19'),
(58, 'Shili', 'unknown', 'unknown', 'unknown', 'temperate', '1', 'cities, savannahs, seas, plains', 'unknown', 'unknown', 'https://swapi.py4e.com/api/planets/58/', '2024-03-03 12:36:20', '2024-03-03 12:36:20'),
(59, 'Kalee', '23', '378', '13850', 'arid, temperate, tropical', '1', 'rainforests, cliffs, canyons, seas', 'unknown', '4000000000', 'https://swapi.py4e.com/api/planets/59/', '2024-03-03 12:36:20', '2024-03-03 12:36:20'),
(60, 'Umbara', 'unknown', 'unknown', 'unknown', 'unknown', 'unknown', 'unknown', 'unknown', 'unknown', 'https://swapi.py4e.com/api/planets/60/', '2024-03-03 12:36:21', '2024-03-03 12:36:21'),
(61, 'Jakku', 'unknown', 'unknown', 'unknown', 'unknown', 'unknown', 'deserts', 'unknown', 'unknown', 'https://swapi.py4e.com/api/planets/61/', '2024-03-03 12:36:21', '2024-03-03 12:36:21');

-- --------------------------------------------------------

--
-- Table structure for table `residents`
--

DROP TABLE IF EXISTS `residents`;
CREATE TABLE `residents` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `planet_id` bigint(20) UNSIGNED NOT NULL,
  `specie_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `height` varchar(255) DEFAULT NULL,
  `mass` varchar(255) DEFAULT NULL,
  `hair_color` varchar(255) DEFAULT NULL,
  `skin_color` varchar(255) DEFAULT NULL,
  `eye_color` varchar(255) DEFAULT NULL,
  `birth_year` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `url` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `residents`
--

INSERT INTO `residents` (`id`, `planet_id`, `specie_id`, `name`, `height`, `mass`, `hair_color`, `skin_color`, `eye_color`, `birth_year`, `gender`, `url`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'Owen Lars', '178', '120', 'brown, grey', 'light', 'blue', '52BBY', 'male', 'https://swapi.py4e.com/api/people/6/', '2024-03-03 12:35:46', '2024-03-03 12:35:46'),
(2, 1, 1, 'Cliegg Lars', '183', 'unknown', 'brown', 'fair', 'blue', '82BBY', 'male', 'https://swapi.py4e.com/api/people/62/', '2024-03-03 12:35:46', '2024-03-03 12:35:46'),
(3, 1, 1, 'Shmi Skywalker', '163', 'unknown', 'black', 'fair', 'brown', '72BBY', 'female', 'https://swapi.py4e.com/api/people/43/', '2024-03-03 12:35:46', '2024-03-03 12:35:46'),
(4, 1, 1, 'Biggs Darklighter', '183', '84', 'black', 'light', 'brown', '24BBY', 'male', 'https://swapi.py4e.com/api/people/9/', '2024-03-03 12:35:47', '2024-03-03 12:35:47'),
(5, 1, 2, 'R5-D4', '97', '32', 'n/a', 'white, red', 'red', 'unknown', 'n/a', 'https://swapi.py4e.com/api/people/8/', '2024-03-03 12:35:47', '2024-03-03 12:35:47'),
(6, 1, 1, 'Beru Whitesun lars', '165', '75', 'brown', 'light', 'blue', '47BBY', 'female', 'https://swapi.py4e.com/api/people/7/', '2024-03-03 12:35:47', '2024-03-03 12:35:47'),
(7, 1, 1, 'Anakin Skywalker', '188', '84', 'blond', 'fair', 'blue', '41.9BBY', 'male', 'https://swapi.py4e.com/api/people/11/', '2024-03-03 12:35:47', '2024-03-03 12:35:47'),
(8, 1, 1, 'Darth Vader', '202', '136', 'none', 'white', 'yellow', '41.9BBY', 'male', 'https://swapi.py4e.com/api/people/4/', '2024-03-03 12:35:47', '2024-03-03 12:35:47'),
(9, 1, 2, 'C-3PO', '167', '75', 'n/a', 'gold', 'yellow', '112BBY', 'n/a', 'https://swapi.py4e.com/api/people/2/', '2024-03-03 12:35:47', '2024-03-03 12:35:47'),
(10, 1, 1, 'Luke Skywalker', '172', '77', 'blond', 'fair', 'blue', '19BBY', 'male', 'https://swapi.py4e.com/api/people/1/', '2024-03-03 12:35:47', '2024-03-03 12:35:47'),
(11, 2, 1, 'Bail Prestor Organa', '191', 'unknown', 'black', 'tan', 'brown', '67BBY', 'male', 'https://swapi.py4e.com/api/people/68/', '2024-03-03 12:35:47', '2024-03-03 12:35:47'),
(12, 2, 1, 'Raymus Antilles', '188', '79', 'brown', 'light', 'brown', 'unknown', 'male', 'https://swapi.py4e.com/api/people/81/', '2024-03-03 12:35:48', '2024-03-03 12:35:48'),
(13, 2, 1, 'Leia Organa', '150', '49', 'brown', 'light', 'brown', '19BBY', 'female', 'https://swapi.py4e.com/api/people/5/', '2024-03-03 12:35:48', '2024-03-03 12:35:48'),
(14, 6, 1, 'Lobot', '175', '79', 'none', 'light', 'blue', '37BBY', 'male', 'https://swapi.py4e.com/api/people/26/', '2024-03-03 12:35:48', '2024-03-03 12:35:48'),
(15, 7, 3, 'Wicket Systri Warrick', '88', '20', 'brown', 'brown', 'brown', '8BBY', 'male', 'https://swapi.py4e.com/api/people/30/', '2024-03-03 12:35:49', '2024-03-03 12:35:49'),
(16, 8, 4, 'Roos Tarpals', '224', '82', 'none', 'grey', 'orange', 'unknown', 'male', 'https://swapi.py4e.com/api/people/37/', '2024-03-03 12:35:49', '2024-03-03 12:35:49'),
(17, 8, NULL, 'Gregar Typho', '185', '85', 'black', 'dark', 'brown', 'unknown', 'male', 'https://swapi.py4e.com/api/people/60/', '2024-03-03 12:35:50', '2024-03-03 12:35:50'),
(18, 8, NULL, 'Cordé', '157', 'unknown', 'brown', 'light', 'brown', 'unknown', 'female', 'https://swapi.py4e.com/api/people/61/', '2024-03-03 12:35:50', '2024-03-03 12:35:50'),
(19, 8, 1, 'Dormé', '165', 'unknown', 'brown', 'light', 'brown', 'unknown', 'female', 'https://swapi.py4e.com/api/people/66/', '2024-03-03 12:35:50', '2024-03-03 12:35:50'),
(20, 8, 1, 'Quarsh Panaka', '183', 'unknown', 'black', 'dark', 'brown', '62BBY', 'male', 'https://swapi.py4e.com/api/people/42/', '2024-03-03 12:35:50', '2024-03-03 12:35:50'),
(21, 8, 4, 'Rugor Nass', '206', 'unknown', 'none', 'green', 'orange', 'unknown', 'male', 'https://swapi.py4e.com/api/people/38/', '2024-03-03 12:35:50', '2024-03-03 12:35:50'),
(22, 8, 4, 'Jar Jar Binks', '196', '66', 'none', 'orange', 'orange', '52BBY', 'male', 'https://swapi.py4e.com/api/people/36/', '2024-03-03 12:35:50', '2024-03-03 12:35:50'),
(23, 8, 1, 'Padmé Amidala', '185', '45', 'brown', 'light', 'brown', '46BBY', 'female', 'https://swapi.py4e.com/api/people/35/', '2024-03-03 12:35:50', '2024-03-03 12:35:50'),
(24, 8, 1, 'Palpatine', '170', '75', 'grey', 'pale', 'yellow', '82BBY', 'male', 'https://swapi.py4e.com/api/people/21/', '2024-03-03 12:35:50', '2024-03-03 12:35:50'),
(25, 8, 2, 'R2-D2', '96', '32', 'n/a', 'white, blue', 'red', '33BBY', 'n/a', 'https://swapi.py4e.com/api/people/3/', '2024-03-03 12:35:50', '2024-03-03 12:35:50'),
(26, 8, 1, 'Ric Olié', '183', 'unknown', 'brown', 'fair', 'blue', 'unknown', 'male', 'https://swapi.py4e.com/api/people/39/', '2024-03-03 12:35:51', '2024-03-03 12:35:51'),
(27, 9, 1, 'Jocasta Nu', '167', 'unknown', 'white', 'fair', 'blue', 'unknown', 'female', 'https://swapi.py4e.com/api/people/74/', '2024-03-03 12:35:51', '2024-03-03 12:35:51'),
(28, 9, 5, 'Adi Gallia', '184', '50', 'none', 'dark', 'blue', 'unknown', 'female', 'https://swapi.py4e.com/api/people/55/', '2024-03-03 12:35:51', '2024-03-03 12:35:51'),
(29, 9, 1, 'Finis Valorum', '170', 'unknown', 'blond', 'fair', 'blue', '91BBY', 'male', 'https://swapi.py4e.com/api/people/34/', '2024-03-03 12:35:51', '2024-03-03 12:35:51'),
(30, 10, 6, 'Taun We', '213', 'unknown', 'none', 'grey', 'black', 'unknown', 'female', 'https://swapi.py4e.com/api/people/73/', '2024-03-03 12:35:52', '2024-03-03 12:35:52'),
(31, 10, 6, 'Lama Su', '229', '88', 'none', 'grey', 'black', 'unknown', 'male', 'https://swapi.py4e.com/api/people/72/', '2024-03-03 12:35:52', '2024-03-03 12:35:52'),
(32, 10, 1, 'Boba Fett', '183', '78.2', 'black', 'fair', 'brown', '31.5BBY', 'male', 'https://swapi.py4e.com/api/people/22/', '2024-03-03 12:35:52', '2024-03-03 12:35:52'),
(33, 11, 7, 'Poggle the Lesser', '183', '80', 'none', 'green', 'yellow', 'unknown', 'male', 'https://swapi.py4e.com/api/people/63/', '2024-03-03 12:35:54', '2024-03-03 12:35:54'),
(34, 12, 8, 'Tion Medon', '206', '80', 'none', 'grey', 'black', 'unknown', 'male', 'https://swapi.py4e.com/api/people/83/', '2024-03-03 12:35:54', '2024-03-03 12:35:54'),
(35, 14, 9, 'Tarfful', '234', '136', 'brown', 'brown', 'blue', 'unknown', 'male', 'https://swapi.py4e.com/api/people/80/', '2024-03-03 12:35:55', '2024-03-03 12:35:55'),
(36, 14, 9, 'Chewbacca', '228', '112', 'brown', 'unknown', 'blue', '200BBY', 'male', 'https://swapi.py4e.com/api/people/13/', '2024-03-03 12:35:55', '2024-03-03 12:35:55'),
(37, 18, 10, 'Nute Gunray', '191', '90', 'none', 'mottled green', 'red', 'unknown', 'male', 'https://swapi.py4e.com/api/people/33/', '2024-03-03 12:35:56', '2024-03-03 12:35:56'),
(38, 20, 1, 'Obi-Wan Kenobi', '182', '77', 'auburn, white', 'fair', 'blue-gray', '57BBY', 'male', 'https://swapi.py4e.com/api/people/10/', '2024-03-03 12:35:57', '2024-03-03 12:35:57'),
(39, 21, 1, 'Wilhuff Tarkin', '180', 'unknown', 'auburn, grey', 'fair', 'blue', '64BBY', 'male', 'https://swapi.py4e.com/api/people/12/', '2024-03-03 12:35:57', '2024-03-03 12:35:57'),
(40, 22, 1, 'Han Solo', '180', '80', 'brown', 'fair', 'brown', '29BBY', 'male', 'https://swapi.py4e.com/api/people/14/', '2024-03-03 12:35:58', '2024-03-03 12:35:58'),
(41, 22, 1, 'Wedge Antilles', '170', '77', 'brown', 'fair', 'hazel', '21BBY', 'male', 'https://swapi.py4e.com/api/people/18/', '2024-03-03 12:35:58', '2024-03-03 12:35:58'),
(42, 23, 11, 'Greedo', '173', '74', 'n/a', 'green', 'black', '44BBY', 'male', 'https://swapi.py4e.com/api/people/15/', '2024-03-03 12:35:58', '2024-03-03 12:35:58'),
(43, 24, 12, 'Jabba Desilijic Tiure', '175', '1,358', 'n/a', 'green-tan, brown', 'orange', '600BBY', 'hermaphrodite', 'https://swapi.py4e.com/api/people/16/', '2024-03-03 12:35:59', '2024-03-03 12:35:59'),
(44, 26, NULL, 'Jek Tono Porkins', '180', '110', 'brown', 'fair', 'blue', 'unknown', 'male', 'https://swapi.py4e.com/api/people/19/', '2024-03-03 12:35:59', '2024-03-03 12:35:59'),
(45, 28, 13, 'Yoda', '66', '17', 'white', 'green', 'brown', '896BBY', 'male', 'https://swapi.py4e.com/api/people/20/', '2024-03-03 12:36:00', '2024-03-03 12:36:00'),
(46, 28, NULL, 'R4-P17', '96', 'unknown', 'none', 'silver, red', 'red, blue', 'unknown', 'female', 'https://swapi.py4e.com/api/people/75/', '2024-03-03 12:36:00', '2024-03-03 12:36:00'),
(47, 28, 2, 'BB8', 'none', 'unknown', 'none', 'none', 'black', 'unknown', 'none', 'https://swapi.py4e.com/api/people/87/', '2024-03-03 12:36:00', '2024-03-03 12:36:00'),
(48, 28, 1, 'Rey', 'unknown', 'unknown', 'brown', 'light', 'hazel', 'unknown', 'female', 'https://swapi.py4e.com/api/people/85/', '2024-03-03 12:36:00', '2024-03-03 12:36:00'),
(49, 28, 1, 'Qui-Gon Jinn', '193', '89', 'brown', 'fair', 'blue', '92BBY', 'male', 'https://swapi.py4e.com/api/people/32/', '2024-03-03 12:36:00', '2024-03-03 12:36:00'),
(50, 28, 1, 'Arvel Crynyd', 'unknown', 'unknown', 'brown', 'fair', 'brown', 'unknown', 'male', 'https://swapi.py4e.com/api/people/29/', '2024-03-03 12:36:00', '2024-03-03 12:36:00'),
(51, 28, 2, 'IG-88', '200', '140', 'none', 'metal', 'red', '15BBY', 'none', 'https://swapi.py4e.com/api/people/23/', '2024-03-03 12:36:00', '2024-03-03 12:36:00'),
(52, 28, 1, 'Finn', 'unknown', 'unknown', 'black', 'dark', 'dark', 'unknown', 'male', 'https://swapi.py4e.com/api/people/84/', '2024-03-03 12:36:01', '2024-03-03 12:36:01'),
(53, 28, 1, 'Captain Phasma', 'none', 'unknown', 'none', 'none', 'unknown', 'unknown', 'female', 'https://swapi.py4e.com/api/people/88/', '2024-03-03 12:36:01', '2024-03-03 12:36:01'),
(54, 28, 1, 'Poe Dameron', 'unknown', 'unknown', 'brown', 'light', 'brown', 'unknown', 'male', 'https://swapi.py4e.com/api/people/86/', '2024-03-03 12:36:03', '2024-03-03 12:36:03'),
(55, 29, 14, 'Bossk', '190', '113', 'none', 'green', 'red', '53BBY', 'male', 'https://swapi.py4e.com/api/people/24/', '2024-03-03 12:36:03', '2024-03-03 12:36:03'),
(56, 30, 1, 'Lando Calrissian', '177', '79', 'black', 'dark', 'brown', '31BBY', 'male', 'https://swapi.py4e.com/api/people/25/', '2024-03-03 12:36:04', '2024-03-03 12:36:04'),
(57, 31, 15, 'Ackbar', '180', '83', 'none', 'brown mottle', 'orange', '41BBY', 'male', 'https://swapi.py4e.com/api/people/27/', '2024-03-03 12:36:05', '2024-03-03 12:36:05'),
(58, 32, 1, 'Mon Mothma', '150', 'unknown', 'auburn', 'fair', 'blue', '48BBY', 'female', 'https://swapi.py4e.com/api/people/28/', '2024-03-03 12:36:05', '2024-03-03 12:36:05'),
(59, 33, 16, 'Nien Nunb', '160', '68', 'none', 'grey', 'black', 'unknown', 'male', 'https://swapi.py4e.com/api/people/31/', '2024-03-03 12:36:06', '2024-03-03 12:36:06'),
(60, 34, 17, 'Watto', '137', 'unknown', 'black', 'blue, grey', 'yellow', 'unknown', 'male', 'https://swapi.py4e.com/api/people/40/', '2024-03-03 12:36:07', '2024-03-03 12:36:07'),
(61, 35, 18, 'Sebulba', '112', '40', 'none', 'grey, red', 'orange', 'unknown', 'male', 'https://swapi.py4e.com/api/people/41/', '2024-03-03 12:36:07', '2024-03-03 12:36:07'),
(62, 36, 19, 'Darth Maul', '175', '80', 'none', 'red', 'yellow', '54BBY', 'male', 'https://swapi.py4e.com/api/people/44/', '2024-03-03 12:36:08', '2024-03-03 12:36:08'),
(63, 37, 20, 'Ayla Secura', '178', '55', 'none', 'blue', 'hazel', '48BBY', 'female', 'https://swapi.py4e.com/api/people/46/', '2024-03-03 12:36:09', '2024-03-03 12:36:09'),
(64, 37, 20, 'Bib Fortuna', '180', 'unknown', 'none', 'pale', 'pink', 'unknown', 'male', 'https://swapi.py4e.com/api/people/45/', '2024-03-03 12:36:09', '2024-03-03 12:36:09'),
(65, 38, 21, 'Ratts Tyerel', '79', '15', 'none', 'grey, blue', 'unknown', 'unknown', 'male', 'https://swapi.py4e.com/api/people/47/', '2024-03-03 12:36:09', '2024-03-03 12:36:09'),
(66, 39, 22, 'Dud Bolt', '94', '45', 'none', 'blue, grey', 'yellow', 'unknown', 'male', 'https://swapi.py4e.com/api/people/48/', '2024-03-03 12:36:10', '2024-03-03 12:36:10'),
(67, 40, 23, 'Gasgano', '122', 'unknown', 'none', 'white, blue', 'black', 'unknown', 'male', 'https://swapi.py4e.com/api/people/49/', '2024-03-03 12:36:10', '2024-03-03 12:36:10'),
(68, 41, 24, 'Ben Quadinaros', '163', '65', 'none', 'grey, green, yellow', 'orange', 'unknown', 'male', 'https://swapi.py4e.com/api/people/50/', '2024-03-03 12:36:11', '2024-03-03 12:36:11'),
(69, 42, 1, 'Mace Windu', '188', '84', 'none', 'dark', 'brown', '72BBY', 'male', 'https://swapi.py4e.com/api/people/51/', '2024-03-03 12:36:12', '2024-03-03 12:36:12'),
(70, 43, 25, 'Ki-Adi-Mundi', '198', '82', 'white', 'pale', 'yellow', '92BBY', 'male', 'https://swapi.py4e.com/api/people/52/', '2024-03-03 12:36:12', '2024-03-03 12:36:12'),
(71, 44, 26, 'Kit Fisto', '196', '87', 'none', 'green', 'black', 'unknown', 'male', 'https://swapi.py4e.com/api/people/53/', '2024-03-03 12:36:13', '2024-03-03 12:36:13'),
(72, 45, 19, 'Eeth Koth', '171', 'unknown', 'black', 'brown', 'brown', 'unknown', 'male', 'https://swapi.py4e.com/api/people/54/', '2024-03-03 12:36:13', '2024-03-03 12:36:13'),
(73, 47, 27, 'Saesee Tiin', '188', 'unknown', 'none', 'pale', 'orange', 'unknown', 'male', 'https://swapi.py4e.com/api/people/56/', '2024-03-03 12:36:14', '2024-03-03 12:36:14'),
(74, 48, 28, 'Yarael Poof', '264', 'unknown', 'none', 'white', 'yellow', 'unknown', 'male', 'https://swapi.py4e.com/api/people/57/', '2024-03-03 12:36:14', '2024-03-03 12:36:14'),
(75, 49, 29, 'Plo Koon', '188', '80', 'none', 'orange', 'black', '22BBY', 'male', 'https://swapi.py4e.com/api/people/58/', '2024-03-03 12:36:15', '2024-03-03 12:36:15'),
(76, 50, 30, 'Mas Amedda', '196', 'unknown', 'none', 'blue', 'blue', 'unknown', 'male', 'https://swapi.py4e.com/api/people/59/', '2024-03-03 12:36:15', '2024-03-03 12:36:15'),
(77, 51, 31, 'Luminara Unduli', '170', '56.2', 'black', 'yellow', 'blue', '58BBY', 'female', 'https://swapi.py4e.com/api/people/64/', '2024-03-03 12:36:17', '2024-03-03 12:36:17'),
(78, 51, 31, 'Barriss Offee', '166', '50', 'black', 'yellow', 'blue', '40BBY', 'female', 'https://swapi.py4e.com/api/people/65/', '2024-03-03 12:36:17', '2024-03-03 12:36:17'),
(79, 52, 1, 'Dooku', '193', '80', 'white', 'fair', 'brown', '102BBY', 'male', 'https://swapi.py4e.com/api/people/67/', '2024-03-03 12:36:17', '2024-03-03 12:36:17'),
(80, 53, 1, 'Jango Fett', '183', '79', 'black', 'tan', 'brown', '66BBY', 'male', 'https://swapi.py4e.com/api/people/69/', '2024-03-03 12:36:17', '2024-03-03 12:36:17'),
(81, 54, 32, 'Zam Wesell', '168', '55', 'blonde', 'fair, green, yellow', 'yellow', 'unknown', 'female', 'https://swapi.py4e.com/api/people/70/', '2024-03-03 12:36:18', '2024-03-03 12:36:18'),
(82, 55, 33, 'Dexter Jettster', '198', '102', 'none', 'brown', 'yellow', 'unknown', 'male', 'https://swapi.py4e.com/api/people/71/', '2024-03-03 12:36:19', '2024-03-03 12:36:19'),
(83, 56, 34, 'Wat Tambor', '193', '48', 'none', 'green, grey', 'unknown', 'unknown', 'male', 'https://swapi.py4e.com/api/people/76/', '2024-03-03 12:36:19', '2024-03-03 12:36:19'),
(84, 57, 35, 'San Hill', '191', 'unknown', 'none', 'grey', 'gold', 'unknown', 'male', 'https://swapi.py4e.com/api/people/77/', '2024-03-03 12:36:20', '2024-03-03 12:36:20'),
(85, 58, 36, 'Shaak Ti', '178', '57', 'none', 'red, blue, white', 'black', 'unknown', 'female', 'https://swapi.py4e.com/api/people/78/', '2024-03-03 12:36:20', '2024-03-03 12:36:20'),
(86, 59, 37, 'Grievous', '216', '159', 'none', 'brown, white', 'green, yellow', 'unknown', 'male', 'https://swapi.py4e.com/api/people/79/', '2024-03-03 12:36:21', '2024-03-03 12:36:21'),
(87, 60, NULL, 'Sly Moore', '178', '48', 'none', 'pale', 'white', 'unknown', 'female', 'https://swapi.py4e.com/api/people/82/', '2024-03-03 12:36:21', '2024-03-03 12:36:21');

-- --------------------------------------------------------

--
-- Table structure for table `species`
--

DROP TABLE IF EXISTS `species`;
CREATE TABLE `species` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `classification` varchar(255) DEFAULT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `average_height` varchar(255) DEFAULT NULL,
  `skin_colors` varchar(255) DEFAULT NULL,
  `hair_colors` varchar(255) DEFAULT NULL,
  `eye_colors` varchar(255) DEFAULT NULL,
  `average_lifespan` varchar(255) DEFAULT NULL,
  `homeworld` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `url` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `species`
--

INSERT INTO `species` (`id`, `name`, `classification`, `designation`, `average_height`, `skin_colors`, `hair_colors`, `eye_colors`, `average_lifespan`, `homeworld`, `language`, `url`, `created_at`, `updated_at`) VALUES
(1, 'Human', 'mammal', 'sentient', '180', 'caucasian, black, asian, hispanic', 'blonde, brown, black, red', 'brown, blue, green, hazel, grey, amber', '120', 'https://swapi.py4e.com/api/planets/9/', 'Galactic Basic', 'https://swapi.py4e.com/api/species/1/', '2024-03-03 12:35:46', '2024-03-03 12:35:46'),
(2, 'Droid', 'artificial', 'sentient', 'n/a', 'n/a', 'n/a', 'n/a', 'indefinite', NULL, 'n/a', 'https://swapi.py4e.com/api/species/2/', '2024-03-03 12:35:47', '2024-03-03 12:35:47'),
(3, 'Ewok', 'mammal', 'sentient', '100', 'brown', 'white, brown, black', 'orange, brown', 'unknown', 'https://swapi.py4e.com/api/planets/7/', 'Ewokese', 'https://swapi.py4e.com/api/species/9/', '2024-03-03 12:35:49', '2024-03-03 12:35:49'),
(4, 'Gungan', 'amphibian', 'sentient', '190', 'brown, green', 'none', 'orange', 'unknown', 'https://swapi.py4e.com/api/planets/8/', 'Gungan basic', 'https://swapi.py4e.com/api/species/12/', '2024-03-03 12:35:49', '2024-03-03 12:35:49'),
(5, 'Tholothian', 'mammal', 'sentient', 'unknown', 'dark', 'unknown', 'blue, indigo', 'unknown', 'https://swapi.py4e.com/api/planets/46/', 'unknown', 'https://swapi.py4e.com/api/species/23/', '2024-03-03 12:35:51', '2024-03-03 12:35:51'),
(6, 'Kaminoan', 'amphibian', 'sentient', '220', 'grey, blue', 'none', 'black', '80', 'https://swapi.py4e.com/api/planets/10/', 'Kaminoan', 'https://swapi.py4e.com/api/species/32/', '2024-03-03 12:35:52', '2024-03-03 12:35:52'),
(7, 'Geonosian', 'insectoid', 'sentient', '178', 'green, brown', 'none', 'green, hazel', 'unknown', 'https://swapi.py4e.com/api/planets/11/', 'Geonosian', 'https://swapi.py4e.com/api/species/28/', '2024-03-03 12:35:54', '2024-03-03 12:35:54'),
(8, 'Pau\'an', 'mammal', 'sentient', '190', 'grey', 'none', 'black', '700', 'https://swapi.py4e.com/api/planets/12/', 'Utapese', 'https://swapi.py4e.com/api/species/37/', '2024-03-03 12:35:54', '2024-03-03 12:35:54'),
(9, 'Wookiee', 'mammal', 'sentient', '210', 'gray', 'black, brown', 'blue, green, yellow, brown, golden, red', '400', 'https://swapi.py4e.com/api/planets/14/', 'Shyriiwook', 'https://swapi.py4e.com/api/species/3/', '2024-03-03 12:35:55', '2024-03-03 12:35:55'),
(10, 'Neimodian', 'unknown', 'sentient', '180', 'grey, green', 'none', 'red, pink', 'unknown', 'https://swapi.py4e.com/api/planets/18/', 'Neimoidia', 'https://swapi.py4e.com/api/species/11/', '2024-03-03 12:35:56', '2024-03-03 12:35:56'),
(11, 'Rodian', 'sentient', 'reptilian', '170', 'green, blue', 'n/a', 'black', 'unknown', 'https://swapi.py4e.com/api/planets/23/', 'Galatic Basic', 'https://swapi.py4e.com/api/species/4/', '2024-03-03 12:35:58', '2024-03-03 12:35:58'),
(12, 'Hutt', 'gastropod', 'sentient', '300', 'green, brown, tan', 'n/a', 'yellow, red', '1000', 'https://swapi.py4e.com/api/planets/24/', 'Huttese', 'https://swapi.py4e.com/api/species/5/', '2024-03-03 12:35:59', '2024-03-03 12:35:59'),
(13, 'Yoda\'s species', 'mammal', 'sentient', '66', 'green, yellow', 'brown, white', 'brown, green, yellow', '900', 'https://swapi.py4e.com/api/planets/28/', 'Galactic basic', 'https://swapi.py4e.com/api/species/6/', '2024-03-03 12:36:00', '2024-03-03 12:36:00'),
(14, 'Trandoshan', 'reptile', 'sentient', '200', 'brown, green', 'none', 'yellow, orange', 'unknown', 'https://swapi.py4e.com/api/planets/29/', 'Dosh', 'https://swapi.py4e.com/api/species/7/', '2024-03-03 12:36:03', '2024-03-03 12:36:03'),
(15, 'Mon Calamari', 'amphibian', 'sentient', '160', 'red, blue, brown, magenta', 'none', 'yellow', 'unknown', 'https://swapi.py4e.com/api/planets/31/', 'Mon Calamarian', 'https://swapi.py4e.com/api/species/8/', '2024-03-03 12:36:05', '2024-03-03 12:36:05'),
(16, 'Sullustan', 'mammal', 'sentient', '180', 'pale', 'none', 'black', 'unknown', 'https://swapi.py4e.com/api/planets/33/', 'Sullutese', 'https://swapi.py4e.com/api/species/10/', '2024-03-03 12:36:06', '2024-03-03 12:36:06'),
(17, 'Toydarian', 'mammal', 'sentient', '120', 'blue, green, grey', 'none', 'yellow', '91', 'https://swapi.py4e.com/api/planets/34/', 'Toydarian', 'https://swapi.py4e.com/api/species/13/', '2024-03-03 12:36:07', '2024-03-03 12:36:07'),
(18, 'Dug', 'mammal', 'sentient', '100', 'brown, purple, grey, red', 'none', 'yellow, blue', 'unknown', 'https://swapi.py4e.com/api/planets/35/', 'Dugese', 'https://swapi.py4e.com/api/species/14/', '2024-03-03 12:36:07', '2024-03-03 12:36:07'),
(19, 'Zabrak', 'mammal', 'sentient', '180', 'pale, brown, red, orange, yellow', 'black', 'brown, orange', 'unknown', 'https://swapi.py4e.com/api/planets/45/', 'Zabraki', 'https://swapi.py4e.com/api/species/22/', '2024-03-03 12:36:08', '2024-03-03 12:36:08'),
(20, 'Twi\'lek', 'mammals', 'sentient', '200', 'orange, yellow, blue, green, pink, purple, tan', 'none', 'blue, brown, orange, pink', 'unknown', 'https://swapi.py4e.com/api/planets/37/', 'Twi\'leki', 'https://swapi.py4e.com/api/species/15/', '2024-03-03 12:36:09', '2024-03-03 12:36:09'),
(21, 'Aleena', 'reptile', 'sentient', '80', 'blue, gray', 'none', 'unknown', '79', 'https://swapi.py4e.com/api/planets/38/', 'Aleena', 'https://swapi.py4e.com/api/species/16/', '2024-03-03 12:36:09', '2024-03-03 12:36:09'),
(22, 'Vulptereen', 'unknown', 'sentient', '100', 'grey', 'none', 'yellow', 'unknown', 'https://swapi.py4e.com/api/planets/39/', 'vulpterish', 'https://swapi.py4e.com/api/species/17/', '2024-03-03 12:36:10', '2024-03-03 12:36:10'),
(23, 'Xexto', 'unknown', 'sentient', '125', 'grey, yellow, purple', 'none', 'black', 'unknown', 'https://swapi.py4e.com/api/planets/40/', 'Xextese', 'https://swapi.py4e.com/api/species/18/', '2024-03-03 12:36:10', '2024-03-03 12:36:10'),
(24, 'Toong', 'unknown', 'sentient', '200', 'grey, green, yellow', 'none', 'orange', 'unknown', 'https://swapi.py4e.com/api/planets/41/', 'Tundan', 'https://swapi.py4e.com/api/species/19/', '2024-03-03 12:36:11', '2024-03-03 12:36:11'),
(25, 'Cerean', 'mammal', 'sentient', '200', 'pale pink', 'red, blond, black, white', 'hazel', 'unknown', 'https://swapi.py4e.com/api/planets/43/', 'Cerean', 'https://swapi.py4e.com/api/species/20/', '2024-03-03 12:36:12', '2024-03-03 12:36:12'),
(26, 'Nautolan', 'amphibian', 'sentient', '180', 'green, blue, brown, red', 'none', 'black', '70', 'https://swapi.py4e.com/api/planets/44/', 'Nautila', 'https://swapi.py4e.com/api/species/21/', '2024-03-03 12:36:13', '2024-03-03 12:36:13'),
(27, 'Iktotchi', 'unknown', 'sentient', '180', 'pink', 'none', 'orange', 'unknown', 'https://swapi.py4e.com/api/planets/47/', 'Iktotchese', 'https://swapi.py4e.com/api/species/24/', '2024-03-03 12:36:14', '2024-03-03 12:36:14'),
(28, 'Quermian', 'mammal', 'sentient', '240', 'white', 'none', 'yellow', '86', 'https://swapi.py4e.com/api/planets/48/', 'Quermian', 'https://swapi.py4e.com/api/species/25/', '2024-03-03 12:36:14', '2024-03-03 12:36:14'),
(29, 'Kel Dor', 'unknown', 'sentient', '180', 'peach, orange, red', 'none', 'black, silver', '70', 'https://swapi.py4e.com/api/planets/49/', 'Kel Dor', 'https://swapi.py4e.com/api/species/26/', '2024-03-03 12:36:15', '2024-03-03 12:36:15'),
(30, 'Chagrian', 'amphibian', 'sentient', '190', 'blue', 'none', 'blue', 'unknown', 'https://swapi.py4e.com/api/planets/50/', 'Chagria', 'https://swapi.py4e.com/api/species/27/', '2024-03-03 12:36:15', '2024-03-03 12:36:15'),
(31, 'Mirialan', 'mammal', 'sentient', '180', 'yellow, green', 'black, brown', 'blue, green, red, yellow, brown, orange', 'unknown', 'https://swapi.py4e.com/api/planets/51/', 'Mirialan', 'https://swapi.py4e.com/api/species/29/', '2024-03-03 12:36:17', '2024-03-03 12:36:17'),
(32, 'Clawdite', 'reptilian', 'sentient', '180', 'green, yellow', 'none', 'yellow', '70', 'https://swapi.py4e.com/api/planets/54/', 'Clawdite', 'https://swapi.py4e.com/api/species/30/', '2024-03-03 12:36:18', '2024-03-03 12:36:18'),
(33, 'Besalisk', 'amphibian', 'sentient', '178', 'brown', 'none', 'yellow', '75', 'https://swapi.py4e.com/api/planets/55/', 'besalisk', 'https://swapi.py4e.com/api/species/31/', '2024-03-03 12:36:19', '2024-03-03 12:36:19'),
(34, 'Skakoan', 'mammal', 'sentient', 'unknown', 'grey, green', 'none', 'unknown', 'unknown', 'https://swapi.py4e.com/api/planets/56/', 'Skakoan', 'https://swapi.py4e.com/api/species/33/', '2024-03-03 12:36:19', '2024-03-03 12:36:19'),
(35, 'Muun', 'mammal', 'sentient', '190', 'grey, white', 'none', 'black', '100', 'https://swapi.py4e.com/api/planets/57/', 'Muun', 'https://swapi.py4e.com/api/species/34/', '2024-03-03 12:36:20', '2024-03-03 12:36:20'),
(36, 'Togruta', 'mammal', 'sentient', '180', 'red, white, orange, yellow, green, blue', 'none', 'red, orange, yellow, green, blue, black', '94', 'https://swapi.py4e.com/api/planets/58/', 'Togruti', 'https://swapi.py4e.com/api/species/35/', '2024-03-03 12:36:20', '2024-03-03 12:36:20'),
(37, 'Kaleesh', 'reptile', 'sentient', '170', 'brown, orange, tan', 'none', 'yellow', '80', 'https://swapi.py4e.com/api/planets/59/', 'Kaleesh', 'https://swapi.py4e.com/api/species/36/', '2024-03-03 12:36:21', '2024-03-03 12:36:21');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `logbooks`
--
ALTER TABLE `logbooks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `logbooks_planet_id_foreign` (`planet_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `planets`
--
ALTER TABLE `planets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `planets_name_unique` (`name`),
  ADD UNIQUE KEY `planets_url_unique` (`url`);

--
-- Indexes for table `residents`
--
ALTER TABLE `residents`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `residents_url_unique` (`url`),
  ADD KEY `residents_planet_id_foreign` (`planet_id`),
  ADD KEY `residents_specie_id_foreign` (`specie_id`),
  ADD KEY `residents_name_index` (`name`);

--
-- Indexes for table `species`
--
ALTER TABLE `species`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `species_url_unique` (`url`),
  ADD KEY `species_name_index` (`name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `logbooks`
--
ALTER TABLE `logbooks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `planets`
--
ALTER TABLE `planets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `residents`
--
ALTER TABLE `residents`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;

--
-- AUTO_INCREMENT for table `species`
--
ALTER TABLE `species`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `logbooks`
--
ALTER TABLE `logbooks`
  ADD CONSTRAINT `logbooks_planet_id_foreign` FOREIGN KEY (`planet_id`) REFERENCES `planets` (`id`);

--
-- Constraints for table `residents`
--
ALTER TABLE `residents`
  ADD CONSTRAINT `residents_planet_id_foreign` FOREIGN KEY (`planet_id`) REFERENCES `planets` (`id`),
  ADD CONSTRAINT `residents_specie_id_foreign` FOREIGN KEY (`specie_id`) REFERENCES `species` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
